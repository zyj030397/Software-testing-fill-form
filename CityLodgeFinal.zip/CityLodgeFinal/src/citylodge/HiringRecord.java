//Xin Xie_s3615651_Advance programming_Assignment_1
package citylodge;

import util.DateTime;

public class HiringRecord {
	public String recordId;
	public DateTime rentDate;
	public DateTime estimatedReturnDate;
	public DateTime actualReturnDate;
	public double rentalFee;
	public double lateFee;
	public String status;
	public String customerId;

	public HiringRecord(String roomId, String customerId, DateTime rentDate, int numOfRentDay) {
		this.customerId = customerId;
		this.rentDate = rentDate;
		this.estimatedReturnDate = new DateTime(rentDate, numOfRentDay);
		this.recordId = roomId + "_" + customerId + "_" + rentDate.toString();
	}

	public String toString() {
		return String.format("%s:%s:%s:%s:%s:%s", recordId, rentDate, estimatedReturnDate, actualReturnDate.toString(),
				rentalFee, lateFee);
	}

	public String getDetails() {
		String result = "";
		result += "Record ID: 			  " + recordId + "\n";
		result += "Rent Date:             " + rentDate + "\n";
		result += "Estimated Return Date: " + rentDate + "\n";
		if (status == "") {
			result += "Actual Return Date:    " + actualReturnDate + "\n";
			result += "Rental Fee:            " + rentalFee + "\n";
			result += "Late Fee:              " + lateFee + "\n";
		}
		return result;
	}
}
