//Xin Xie_s3615651_Advance programming_Assignment_1
package citylodge;

import java.util.ArrayList;
import java.util.List;

import util.DateTime;

public class Room {

	public String roomId;
	public int cntBedroom;
	public String status;
	public String features;
	public String roomType;

	public List<HiringRecord> records = new ArrayList<HiringRecord>();

	public boolean rent(String customerId, DateTime rentDate, int numOfRentDay) {
		if (this.status != "Available") {
			return false;
		}
		if (records.size() >= 10) {
			records.remove(0);
		}

		if (rentDate.getNameOfDay().toLowerCase().equals("saturday")
				|| rentDate.getNameOfDay().toLowerCase().equals("sunday")) {
			if (numOfRentDay < 3) {
				System.out.println("The numbers of day for rent should be at least 3");
				return false;
			}
		} else {
			if (numOfRentDay < 2) {
				System.out.println("The numbers of day for rent should be at least 2");
				return false;
			}
		}
		if (numOfRentDay > 10) {
			System.out.println("The numbers of day for rent should be at most 10");
			return false;
		}

		this.status = "Rented";
		records.add(new HiringRecord(roomId, customerId, rentDate, numOfRentDay));
		return true;
	}

	public boolean returnRoom(DateTime returnDate) {
		if (this.status != "Rented") {
			return false;
		}
		if (DateTime.diffDays(returnDate, this.records.get(this.records.size() - 1).rentDate) < 1) {
			return false;
		}
		this.status = "Available";
		double rentalDailyFee;
		if (this.cntBedroom == 1) {
			rentalDailyFee = 59;
		} else if (this.cntBedroom == 2) {
			rentalDailyFee = 99;
		} else {
			rentalDailyFee = 199;
		}
		this.records.get(this.records.size() - 1).status = "Returned";
		this.records.get(this.records.size() - 1).actualReturnDate = returnDate;

		if (DateTime.diffDays(returnDate, this.records.get(this.records.size() - 1).estimatedReturnDate) > 0) {
			this.records.get(this.records.size() - 1).rentalFee = rentalDailyFee
					* DateTime.diffDays(this.records.get(this.records.size() - 1).estimatedReturnDate,
							this.records.get(this.records.size() - 1).rentDate);
			rentalDailyFee = 135.0 / 100.0 * rentalDailyFee;
			this.records.get(this.records.size() - 1).lateFee = rentalDailyFee
					* DateTime.diffDays(returnDate, this.records.get(this.records.size() - 1).estimatedReturnDate);
		} else {
			this.records.get(this.records.size() - 1).rentalFee = rentalDailyFee
					* DateTime.diffDays(returnDate, this.records.get(this.records.size() - 1).rentDate);
		}
		return true;
	}

	public boolean performMaintenance() {
		if (this.status == "Rented") {
			return false;
		}
		if (this.status == "Maintenance") {
			System.out.println("The room is already maintenance");
			return false;
		}
		this.status = "Maintenance";
		return true;
	}

	public boolean completeMaintenance() {

		if (this.status != "Maintenance") {
			return false;
		}
		this.status = "Available";

		return true;
	}

	public String toString() {
		return String.format("%s:%s:%s:%s:%s", this.roomId, this.cntBedroom, "Standard", this.status, this.features);
	}

	public String getDetails() {
		String result = "";
		result += "Room ID:               " + this.roomId + "\n";
		result += "Number of bedrooms:    " + this.cntBedroom + "\n";
		result += "Type:                  " + "Standard" + "\n";
		result += "Status:                " + this.status + "\n";
		result += "Feature summary:       " + this.features + "\n";
		if (this.records.size() == 0) {
			result += "RENTAL RECORD:         " + "empty" + "\n";
		} else {
			result += "RENTAL RECORD" + "\n";
			for (int i = this.records.size() - 1; i >= 0; i--) {
				result += "Record ID:             " + this.records.get(i).recordId + "\n";
				result += "Rent Date:             " + this.records.get(i).rentDate + "\n";
				result += "Estimated Return Date: " + this.records.get(i).estimatedReturnDate + "\n";
				if (this.records.get(i).status == "Returned") {
					result += "Actual Return Date:    " + this.records.get(i).actualReturnDate + "\n";
					result += "Rental Fee:            " + this.records.get(i).rentalFee + "\n";
					result += "Late Fee:              " + this.records.get(i).lateFee + "\n";
				}
				result += "------------------------------------------\n";
			}
		}
		return result;
	}
}
