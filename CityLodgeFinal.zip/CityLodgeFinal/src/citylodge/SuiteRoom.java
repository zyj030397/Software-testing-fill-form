//Xin Xie_s3615651_Advance programming_Assignment_1
package citylodge;

import util.DateTime;

public class SuiteRoom extends Room {

	public DateTime lastMaintenanceDate;

	public SuiteRoom(String roomId, DateTime lastMaintenanceDate, String features) {
		this.roomId = roomId;
		this.roomType = "Suite";
		this.cntBedroom = 6;
		this.lastMaintenanceDate = lastMaintenanceDate;
		this.status = "Available";
		this.features = features;
	}

	public boolean rent(String customerId, DateTime rentDate, int numOfRentDay) {
		if (status == "Rented") {
			return false;
		}
		if (records.size() >= 10) {
			records.remove(0);
		}

		if (DateTime.diffDays(lastMaintenanceDate, rentDate) < -10 + numOfRentDay) {
			return false;
		}

		this.status = "Rented";
		records.add(new HiringRecord(roomId, customerId, rentDate, numOfRentDay));
		return true;
	}

	public boolean returnRoom(DateTime returnDate) {

		if (this.status != "Rented") {
			return false;
		}
		if (DateTime.diffDays(returnDate, this.records.get(this.records.size() - 1).rentDate) < 1) {
			return false;
		}
		this.status = "Available";
		double rentalDailyFee = 999;

		this.records.get(this.records.size() - 1).status = "Returned";
		this.records.get(this.records.size() - 1).actualReturnDate = returnDate;
		this.records.get(this.records.size() - 1).rentalFee = rentalDailyFee
				* DateTime.diffDays(returnDate, this.records.get(this.records.size() - 1).rentDate);

		if (DateTime.diffDays(returnDate, this.records.get(this.records.size() - 1).estimatedReturnDate) > 0) {
			rentalDailyFee = 1099;
			this.records.get(this.records.size() - 1).lateFee = rentalDailyFee
					* DateTime.diffDays(returnDate, this.records.get(this.records.size() - 1).estimatedReturnDate);
		}

		return true;
	}

	public boolean completeMaintenance(DateTime completionDate) {

		if (this.status == "Rented") {
			return false;
		}
		this.status = "Available";
		this.lastMaintenanceDate = completionDate;
		return true;
	}

	@Override
	public String toString() {
		return String.format("%s:%s:%s:%s:%s:%s", this.roomId, this.cntBedroom, "Suite", this.status,
				this.lastMaintenanceDate, this.features);
	}

	@Override
	public String getDetails() {
		String result = "";
		result += "Room ID:               " + this.roomId + "\n";
		result += "Number of bedrooms:    " + this.cntBedroom + "\n";
		result += "Type:                  " + "Suite" + "\n";
		result += "Status:                " + this.status + "\n";
		result += "Last maintenance Date: " + this.lastMaintenanceDate + "\n";
		result += "Feature summary:       " + this.features + "\n";
		if (this.records.size() == 0) {
			result += "RENTAL RECORD:         " + "empty" + "\n";
		} else {
			result += "RENTAL RECORD" + "\n";
			for (int i = this.records.size() - 1; i >= 0; i--) {
				result += "Record ID:             " + this.records.get(i).recordId + "\n";
				result += "Rent Date:             " + this.records.get(i).rentDate + "\n";
				result += "Estimated Return Date: " + this.records.get(i).estimatedReturnDate + "\n";

				if (this.records.get(i).status == "Returned") {
					result += "Actual Return Date:    " + this.records.get(i).actualReturnDate + "\n";
					result += "Rental Fee:            " + this.records.get(i).rentalFee + "\n";
					result += "Late Fee:              " + this.records.get(i).lateFee + "\n";
				}
				result += "------------------------------------------\n";
			}
		}
		return result;
	}
}
