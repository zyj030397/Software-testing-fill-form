//Xin Xie_s3615651_Advance programming_Assignment_1
package citylodge;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import util.DateTime;

public class CityLodge {

	public static List<Room> rooms;
	// public static List<SuiteRoom> sRoom;
	public static Scanner in;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		init();

		while (true) {
			printMenu();

			String strChoice = in.next();
			if (strChoice.charAt(0) < '1' || strChoice.charAt(0) > '7' || strChoice.length() != 1) {
				System.out.println("Please input correct number");
				continue;
			}
			int choice = Integer.parseInt(strChoice);
			switch (choice) {
			case 1:
				addRoom();
				break;
			case 2:
				rentRoom();
				break;
			case 3:
				returnRoom();
				break;
			case 4:
				roomMaintenance();
				break;
			case 5:
				completeMaintenance();
				break;
			case 6:
				displayAllRooms();
				break;
			case 7:
				System.exit(0);
				break;
			}

		}

	}

	public static void init() {
		rooms = new ArrayList<Room>();
		// sRoom = new ArrayList<SuiteRoom>();
		in = new Scanner(System.in);
	}

	public static void addRoom() {

		System.out.print("Room Id(R_XXX for Standard, S_XXX for Suite): ");
		String roomId = in.next();

		if (checkVaildRoomId(roomId) == false) {
			return;
		}
		for (int i = 0; i < rooms.size(); i++) {
			if (rooms.get(i).roomId.equals(roomId)) {
				System.out.println("Duplicate room id");
				return;
			}
		}
		String roomType = "Suite";
		if (roomId.charAt(0) == 'R') {
			roomType = "Standard";
		}

		if (roomType.equals("Standard")) {
			System.out.print("Number Of BedRooms(1, 2, 4): ");
			int cntBedRoom = 0;
			try {
				cntBedRoom = in.nextInt();
				if (checkValidCntBedRoom(cntBedRoom) == false) {
					return;
				}
			} catch (Exception e) {
				System.out.println("Please input integer for number of bedrooms");
				return;
			}
			System.out.print("Feature summary(like TV): ");
			String features = in.next();

			rooms.add(new StandardRoom(roomId, cntBedRoom, features));
		} else if (roomType.equals("Suite")) {

			System.out.print("Last maintenance date(dd/mm/yyyy): ");
			String[] dateStr = in.next().split("/");

			if (checkValidDate(dateStr) == false) {
				return;
			}

			DateTime lastMaintenanceDate = new DateTime(Integer.parseInt(dateStr[0]), Integer.parseInt(dateStr[1]),
					Integer.parseInt(dateStr[2]));
			System.out.print("Feature summary(like TV): ");
			String features = in.next();
			rooms.add(new SuiteRoom(roomId, lastMaintenanceDate, features));
		}

		System.out.println(String.format("Room %s was successfully added", roomId));
		return;
	}

	public static void rentRoom() {

		System.out.print("Room Id: ");
		String roomId = in.next();

		if (checkVaildRoomId(roomId) == false) {
			return;
		}
		int roomIndex = findRoom(roomId);

		if (roomIndex == -1) {
			System.out.println(String.format("Room %s doesn't exist.", roomId));
			return;
		}
		System.out.print("Customer Id: ");
		String cusId = in.next();

		System.out.print("Rent date(dd/mm/yyyy): ");
		String[] dateStr = in.next().split("/");
		if (checkValidDate(dateStr) == false) {
			return;
		}
		DateTime rentDate = new DateTime(Integer.parseInt(dateStr[0]), Integer.parseInt(dateStr[1]),
				Integer.parseInt(dateStr[2]));
		System.out.print("How many days?: ");
		int numOfRentDay = in.nextInt();

		String roomType = rooms.get(roomIndex).roomType.equals("Standard") == true ? "Room" : "Suite";
		if ((rooms.get(roomIndex)).rent(cusId, rentDate, numOfRentDay) == true) {
			System.out.println(
					String.format("%s %s is now rented by customer %s ", roomType, rooms.get(roomIndex).roomId, cusId));
		} else {
			System.out.println(
					String.format("%s %s is not rented at the moment.", roomType, rooms.get(roomIndex).roomId));
		}
	}

	public static void returnRoom() {
		System.out.print("Room Id: ");
		String roomId = in.next();

		if (checkVaildRoomId(roomId) == false) {
			return;
		}

		int roomIndex = findRoom(roomId);

		if (roomIndex == -1) {
			System.out.println(String.format("Room %s doesn't exist.", roomId));
			return;
		}
		System.out.print("Return date(dd/mm/yyyy): ");
		String[] dateStr = in.next().split("/");
		if (checkValidDate(dateStr) == false) {
			return;
		}
		DateTime returnDate = new DateTime(Integer.parseInt(dateStr[0]), Integer.parseInt(dateStr[1]),
				Integer.parseInt(dateStr[2]));

		String roomType = rooms.get(roomIndex).roomType == "Standard" ? "Room" : "Suite";
		if ((rooms.get(roomIndex)).returnRoom(returnDate) == true) {
			System.out.println(String.format("%s %s is now returned", roomType, rooms.get(roomIndex).roomId));
			displayRoom(roomId);
		} else {
			System.out.println(
					String.format("%s %s is not returned at the moment.", roomType, rooms.get(roomIndex).roomId));
		}
	}

	public static void roomMaintenance() {
		System.out.print("Room Id: ");
		String roomId = in.next();

		if (checkVaildRoomId(roomId) == false) {
			return;
		}

		int roomIndex = findRoom(roomId);

		if (roomIndex == -1) {
			System.out.println(String.format("Room %s doesn't exist.", roomId));
			return;
		}
		String roomType = rooms.get(roomIndex).roomType == "Standard" ? "Room" : "Suite";
		if ((rooms.get(roomIndex)).performMaintenance() == true) {
			System.out.println(String.format("%s %s is now under maintenance.", roomType, rooms.get(roomIndex).roomId));
		} else {
			System.out.println(
					String.format("%s %s is not available at the moment.", roomType, rooms.get(roomIndex).roomId));
		}
	}

	public static void completeMaintenance() {
		System.out.print("Room Id: ");
		String roomId = in.next();

		if (checkVaildRoomId(roomId) == false) {
			return;
		}

		int roomIndex = findRoom(roomId);

		if (roomIndex == -1) {
			System.out.println(String.format("Room %s doesn't exist.", roomId));
			return;
		}
		String roomType = rooms.get(roomIndex).roomType.equals("Standard") == true ? "Room" : "Suite";

		if (roomType.equals("Suite")) {
			System.out.print("Maintenance completion date(dd/mm/yyyy): ");
			String[] dateStr = in.next().split("/");
			if (checkValidDate(dateStr) == false) {
				return;
			}
			DateTime completeDate = new DateTime(Integer.parseInt(dateStr[0]), Integer.parseInt(dateStr[1]),
					Integer.parseInt(dateStr[2]));
			if (((SuiteRoom) rooms.get(roomIndex)).completeMaintenance(completeDate) == true) {
				System.out.println(
						String.format("%s %s has all maintenance operations completed and is now ready for rent.",
								roomType, rooms.get(roomIndex).roomId));
			} else {
				System.out.println(
						String.format("%s %s is not available at the moment.", roomType, rooms.get(roomIndex).roomId));
			}
		} else {
			if ((rooms.get(roomIndex)).completeMaintenance() == true) {
				System.out.println(
						String.format("%s %s has all maintenance operations completed and is now ready for rent.",
								roomType, rooms.get(roomIndex).roomId));
			} else {
				System.out.println(
						String.format("%s %s is not available at the moment.", roomType, rooms.get(roomIndex).roomId));
			}
		}

	}

	public static void displayRoom(String roomId) {
		for (int i = 0; i < rooms.size(); i++) {
			if (rooms.get(i).roomId.equals(roomId)) {
				System.out.print(rooms.get(i).getDetails());
				break;
			}
		}
		return;
	}

	public static void displayAllRooms() {

		for (int i = 0; i < rooms.size(); i++) {
			System.out.print(rooms.get(i).getDetails());
		}
	}

	public static int findRoom(String roomId) {

		for (int i = 0; i < rooms.size(); i++) {
			if (rooms.get(i).roomId.equals(roomId)) {
				return i;
			}
		}
		return -1;
	}

	public static boolean checkVaildRoomId(String roomId) {

		if (roomId.length() < 3) {
			System.out.println("Please input correct room id like sample R_104");
			return false;
		}
		if ((roomId.charAt(0) != 'R' && roomId.charAt(0) != 'S') || roomId.charAt(1) != '_') {
			System.out.println("Please input correct room id like sample R_104");
			return false;
		}
		return true;
	}

	// public static boolean checkValidRoomType(String roomType) {
	//
	// if( !roomType.equals("Suite") && !roomType.equals("Standard") ) {
	// System.out.println("Please input correct room type (Standard or Suite)");
	// return false;
	// }
	// return true;
	// }
	public static boolean checkValidCntBedRoom(int cntBedRoom) {
		if (cntBedRoom != 1 && cntBedRoom != 2 && cntBedRoom != 4) {
			System.out.println("Please input correct number of bedrooms (1, 2, 4");
			return false;
		}
		return true;
	}

	public static boolean checkValidDate(String[] dateStr) {
		if (dateStr.length != 3) {
			System.out.println("Please input correct date (dd/mm/yyyy)");
			return false;
		}
		return true;
	}

	public static void printMenu() {
		System.out.println("**** CITYLODGE MAIN MENU ****");
		System.out.println("Add Room:                 1 *");
		System.out.println("Rent Room:                2 *");
		System.out.println("Return Room:              3 *");
		System.out.println("Room Maintenance:         4 *");
		System.out.println("Complete Maintenance:     5 *");
		System.out.println("Display All Rooms:        6 *");
		System.out.println("Exit Program:             7 *");
		System.out.println("*****************************");
		System.out.println("Enter your choice");
	}

}
