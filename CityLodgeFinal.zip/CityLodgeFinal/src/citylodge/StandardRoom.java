//Xin Xie_s3615651_Advance programming_Assignment_1
package citylodge;

public class StandardRoom extends Room {

	public StandardRoom(String roomId, int cntBedroom, String features) {
		this.roomId = roomId;
		this.roomType = "Standard";
		this.cntBedroom = cntBedroom;
		this.status = "Available";
		this.features = features;
		// this.features = "air conditioning, cable TV, Wifi, fridge";
	}

}
